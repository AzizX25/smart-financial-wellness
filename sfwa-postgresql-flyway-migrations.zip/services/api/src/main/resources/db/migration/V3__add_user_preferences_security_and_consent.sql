ALTER TABLE app_user
    ADD COLUMN email_verified_at TIMESTAMPTZ,
    ADD COLUMN last_access_at TIMESTAMPTZ,
    ADD COLUMN version INTEGER NOT NULL DEFAULT 0,
    ADD CONSTRAINT ck_app_user_status
        CHECK (status IN ('PENDING_VERIFICATION', 'ACTIVE', 'SUSPENDED', 'DELETION_PENDING', 'DELETED'));

CREATE TABLE user_profile (
    user_id UUID PRIMARY KEY REFERENCES app_user(id) ON DELETE CASCADE,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    display_name VARCHAR(160),
    avatar_reference VARCHAR(500),
    country_code CHAR(2),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_user_profile_country
        CHECK (country_code IS NULL OR country_code = UPPER(country_code))
);

CREATE TABLE interface_preference (
    user_id UUID PRIMARY KEY REFERENCES app_user(id) ON DELETE CASCADE,
    language_tag VARCHAR(35) NOT NULL DEFAULT 'fr-TN',
    time_zone VARCHAR(80) NOT NULL DEFAULT 'Africa/Tunis',
    theme VARCHAR(20) NOT NULL DEFAULT 'SYSTEM',
    text_size VARCHAR(20) NOT NULL DEFAULT 'NORMAL',
    high_contrast BOOLEAN NOT NULL DEFAULT FALSE,
    reduced_motion BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_interface_preference_theme CHECK (theme IN ('LIGHT', 'DARK', 'SYSTEM')),
    CONSTRAINT ck_interface_preference_text_size CHECK (text_size IN ('NORMAL', 'LARGE', 'EXTRA_LARGE'))
);

CREATE TABLE financial_preference (
    user_id UUID PRIMARY KEY REFERENCES app_user(id) ON DELETE CASCADE,
    primary_currency CHAR(3) NOT NULL DEFAULT 'TND',
    month_start_day SMALLINT NOT NULL DEFAULT 1,
    low_balance_threshold NUMERIC(19, 4),
    hide_home_amounts BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_financial_preference_currency CHECK (primary_currency = UPPER(primary_currency)),
    CONSTRAINT ck_financial_preference_month_start CHECK (month_start_day BETWEEN 1 AND 28),
    CONSTRAINT ck_financial_preference_low_balance CHECK (low_balance_threshold IS NULL OR low_balance_threshold >= 0)
);

CREATE TABLE profile_change_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    change_type VARCHAR(60) NOT NULL,
    masked_previous_values JSONB,
    masked_new_values JSONB,
    correlation_id UUID,
    changed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE auth_session (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    device_label VARCHAR(160),
    user_agent_hash CHAR(64),
    ip_address_hash CHAR(64),
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_auth_session_status CHECK (status IN ('ACTIVE', 'EXPIRED', 'REVOKED')),
    CONSTRAINT ck_auth_session_expiry CHECK (expires_at > created_at),
    CONSTRAINT ck_auth_session_revocation CHECK (revoked_at IS NULL OR revoked_at >= created_at)
);

ALTER TABLE refresh_token
    ADD COLUMN session_id UUID REFERENCES auth_session(id) ON DELETE CASCADE,
    ADD COLUMN used_at TIMESTAMPTZ;

CREATE TABLE mfa_factor (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    factor_type VARCHAR(20) NOT NULL,
    encrypted_secret TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    verified_at TIMESTAMPTZ,
    last_used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_mfa_factor_type CHECK (factor_type IN ('TOTP', 'RECOVERY_CODES')),
    CONSTRAINT ck_mfa_factor_status CHECK (status IN ('PENDING', 'ACTIVE', 'REVOKED'))
);

CREATE UNIQUE INDEX uk_mfa_factor_active_type
    ON mfa_factor(user_id, factor_type)
    WHERE status IN ('PENDING', 'ACTIVE');

CREATE TABLE account_action_token (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    action_type VARCHAR(40) NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_account_action_token_hash UNIQUE (token_hash),
    CONSTRAINT ck_account_action_token_type
        CHECK (action_type IN ('VERIFY_EMAIL', 'RESET_PASSWORD', 'CONFIRM_EMAIL_CHANGE', 'CONFIRM_ACCOUNT_DELETION')),
    CONSTRAINT ck_account_action_token_expiry CHECK (expires_at > created_at),
    CONSTRAINT ck_account_action_token_use CHECK (used_at IS NULL OR used_at >= created_at)
);

CREATE TABLE security_event (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES app_user(id) ON DELETE SET NULL,
    event_type VARCHAR(60) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    outcome VARCHAR(20) NOT NULL,
    ip_address_hash CHAR(64),
    user_agent_hash CHAR(64),
    correlation_id UUID,
    details JSONB,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_security_event_severity CHECK (severity IN ('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_security_event_outcome CHECK (outcome IN ('SUCCEEDED', 'FAILED', 'BLOCKED'))
);

CREATE TABLE legal_document_version (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_type VARCHAR(40) NOT NULL,
    version VARCHAR(40) NOT NULL,
    content_hash CHAR(64) NOT NULL,
    publication_uri VARCHAR(500),
    published_at TIMESTAMPTZ NOT NULL,
    retired_at TIMESTAMPTZ,
    CONSTRAINT uk_legal_document_version UNIQUE (document_type, version),
    CONSTRAINT ck_legal_document_dates CHECK (retired_at IS NULL OR retired_at >= published_at)
);

CREATE TABLE legal_document_acceptance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    legal_document_version_id UUID NOT NULL REFERENCES legal_document_version(id) ON DELETE RESTRICT,
    accepted_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    evidence JSONB,
    CONSTRAINT uk_legal_document_acceptance UNIQUE (user_id, legal_document_version_id)
);

CREATE TABLE user_consent (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    consent_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL,
    policy_version VARCHAR(40) NOT NULL,
    granted_at TIMESTAMPTZ,
    withdrawn_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT uk_user_consent UNIQUE (user_id, consent_type),
    CONSTRAINT ck_user_consent_status CHECK (status IN ('GRANTED', 'WITHDRAWN', 'NOT_REQUESTED')),
    CONSTRAINT ck_user_consent_dates CHECK (withdrawn_at IS NULL OR granted_at IS NULL OR withdrawn_at >= granted_at)
);

CREATE TABLE consent_event (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_consent_id UUID NOT NULL REFERENCES user_consent(id) ON DELETE CASCADE,
    event_type VARCHAR(20) NOT NULL,
    policy_version VARCHAR(40) NOT NULL,
    evidence JSONB,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_consent_event_type CHECK (event_type IN ('GRANTED', 'WITHDRAWN', 'RECONFIRMED'))
);

CREATE INDEX idx_profile_change_history_user_date ON profile_change_history(user_id, changed_at DESC);
CREATE INDEX idx_auth_session_user_state ON auth_session(user_id, status, expires_at);
CREATE INDEX idx_refresh_token_session ON refresh_token(session_id);
CREATE INDEX idx_account_action_token_user_type ON account_action_token(user_id, action_type, expires_at);
CREATE INDEX idx_security_event_user_date ON security_event(user_id, detected_at DESC);
CREATE INDEX idx_consent_event_consent_date ON consent_event(user_consent_id, occurred_at DESC);
