CREATE TABLE monthly_plan (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE RESTRICT,
    period_month DATE NOT NULL,
    currency CHAR(3) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
    expected_income_total NUMERIC(19, 4) NOT NULL DEFAULT 0,
    recommended_expense_budget NUMERIC(19, 4) NOT NULL DEFAULT 0,
    calculated_saving_capacity NUMERIC(19, 4) NOT NULL DEFAULT 0,
    calculation_method VARCHAR(80) NOT NULL,
    method_version VARCHAR(60) NOT NULL,
    calculated_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT uk_monthly_plan UNIQUE (user_id, period_month, currency),
    CONSTRAINT ck_monthly_plan_month CHECK (period_month = DATE_TRUNC('month', period_month)::DATE),
    CONSTRAINT ck_monthly_plan_currency CHECK (currency = UPPER(currency)),
    CONSTRAINT ck_monthly_plan_status CHECK (status IN ('DRAFT', 'ACTIVE', 'CLOSED', 'ARCHIVED')),
    CONSTRAINT ck_monthly_plan_amounts CHECK (
        expected_income_total >= 0 AND
        recommended_expense_budget >= 0 AND
        calculated_saving_capacity >= 0
    )
);

CREATE TABLE planned_income (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    monthly_plan_id UUID NOT NULL REFERENCES monthly_plan(id) ON DELETE CASCADE,
    label VARCHAR(160) NOT NULL,
    income_type VARCHAR(30) NOT NULL,
    expected_amount NUMERIC(19, 4) NOT NULL,
    expected_date DATE,
    recurring BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_planned_income_type CHECK (income_type IN ('SALARY', 'FREELANCE', 'BENEFIT', 'GIFT', 'OTHER')),
    CONSTRAINT ck_planned_income_amount CHECK (expected_amount > 0)
);

CREATE TABLE budget_allocation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    monthly_plan_id UUID NOT NULL REFERENCES monthly_plan(id) ON DELETE CASCADE,
    category_code VARCHAR(60) NOT NULL REFERENCES category(code) ON DELETE RESTRICT,
    recommended_amount NUMERIC(19, 4) NOT NULL DEFAULT 0,
    confirmed_amount NUMERIC(19, 4),
    recommendation_origin VARCHAR(30) NOT NULL,
    confirmed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT uk_budget_allocation UNIQUE (monthly_plan_id, category_code),
    CONSTRAINT ck_budget_allocation_origin CHECK (recommendation_origin IN ('RULES', 'ML', 'USER', 'HYBRID')),
    CONSTRAINT ck_budget_allocation_amounts CHECK (
        recommended_amount >= 0 AND
        (confirmed_amount IS NULL OR confirmed_amount >= 0)
    ),
    CONSTRAINT ck_budget_allocation_confirmation CHECK (
        (confirmed_amount IS NULL AND confirmed_at IS NULL) OR
        (confirmed_amount IS NOT NULL AND confirmed_at IS NOT NULL)
    )
);

CREATE TABLE financial_goal (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE RESTRICT,
    name VARCHAR(160) NOT NULL,
    description VARCHAR(1000),
    goal_type VARCHAR(40) NOT NULL,
    currency CHAR(3) NOT NULL,
    target_amount NUMERIC(19, 4) NOT NULL,
    initial_amount NUMERIC(19, 4) NOT NULL DEFAULT 0,
    target_date DATE,
    priority VARCHAR(20) NOT NULL DEFAULT 'MEDIUM',
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_financial_goal_type
        CHECK (goal_type IN ('EMERGENCY_FUND', 'PURCHASE', 'TRAVEL', 'EDUCATION', 'DEBT_REPAYMENT', 'RETIREMENT', 'OTHER')),
    CONSTRAINT ck_financial_goal_currency CHECK (currency = UPPER(currency)),
    CONSTRAINT ck_financial_goal_priority CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_financial_goal_status CHECK (status IN ('ACTIVE', 'PAUSED', 'ACHIEVED', 'CANCELLED', 'ARCHIVED')),
    CONSTRAINT ck_financial_goal_amounts CHECK (
        target_amount > 0 AND initial_amount >= 0 AND initial_amount <= target_amount
    )
);

CREATE TABLE goal_allocation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    monthly_plan_id UUID NOT NULL REFERENCES monthly_plan(id) ON DELETE CASCADE,
    financial_goal_id UUID NOT NULL REFERENCES financial_goal(id) ON DELETE RESTRICT,
    planned_amount NUMERIC(19, 4) NOT NULL,
    confirmed_amount NUMERIC(19, 4),
    status VARCHAR(20) NOT NULL DEFAULT 'PROPOSED',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT uk_goal_allocation UNIQUE (monthly_plan_id, financial_goal_id),
    CONSTRAINT ck_goal_allocation_status CHECK (status IN ('PROPOSED', 'CONFIRMED', 'CANCELLED')),
    CONSTRAINT ck_goal_allocation_amounts CHECK (
        planned_amount >= 0 AND (confirmed_amount IS NULL OR confirmed_amount >= 0)
    ),
    CONSTRAINT ck_goal_allocation_confirmation CHECK (
        (status = 'CONFIRMED' AND confirmed_amount IS NOT NULL) OR
        (status <> 'CONFIRMED')
    )
);

CREATE TABLE goal_contribution (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    financial_goal_id UUID NOT NULL REFERENCES financial_goal(id) ON DELETE RESTRICT,
    transaction_id UUID REFERENCES transaction_record(id) ON DELETE SET NULL,
    amount NUMERIC(19, 4) NOT NULL,
    contribution_date DATE NOT NULL,
    source VARCHAR(20) NOT NULL,
    note VARCHAR(500),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_goal_contribution_amount CHECK (amount > 0),
    CONSTRAINT ck_goal_contribution_source CHECK (source IN ('TRANSACTION', 'MANUAL', 'IMPORT')),
    CONSTRAINT ck_goal_contribution_transaction CHECK (
        (source = 'TRANSACTION' AND transaction_id IS NOT NULL) OR
        (source <> 'TRANSACTION')
    )
);

CREATE UNIQUE INDEX uk_goal_contribution_transaction
    ON goal_contribution(financial_goal_id, transaction_id)
    WHERE transaction_id IS NOT NULL;

CREATE TABLE goal_scenario (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    financial_goal_id UUID NOT NULL REFERENCES financial_goal(id) ON DELETE CASCADE,
    name VARCHAR(160) NOT NULL,
    simulated_monthly_contribution NUMERIC(19, 4) NOT NULL,
    simulated_initial_amount NUMERIC(19, 4) NOT NULL DEFAULT 0,
    start_date DATE NOT NULL,
    estimated_completion_date DATE,
    estimated_month_count INTEGER,
    method_version VARCHAR(60) NOT NULL,
    assumptions JSONB NOT NULL DEFAULT '{}'::JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_goal_scenario_amounts CHECK (
        simulated_monthly_contribution > 0 AND simulated_initial_amount >= 0
    ),
    CONSTRAINT ck_goal_scenario_month_count CHECK (estimated_month_count IS NULL OR estimated_month_count >= 0),
    CONSTRAINT ck_goal_scenario_completion CHECK (
        estimated_completion_date IS NULL OR estimated_completion_date >= start_date
    )
);

CREATE INDEX idx_monthly_plan_user_month ON monthly_plan(user_id, period_month DESC);
CREATE INDEX idx_planned_income_plan ON planned_income(monthly_plan_id);
CREATE INDEX idx_budget_allocation_plan ON budget_allocation(monthly_plan_id);
CREATE INDEX idx_financial_goal_user_status ON financial_goal(user_id, status);
CREATE INDEX idx_goal_allocation_goal ON goal_allocation(financial_goal_id);
CREATE INDEX idx_goal_contribution_goal_date ON goal_contribution(financial_goal_id, contribution_date DESC);
CREATE INDEX idx_goal_scenario_goal_date ON goal_scenario(financial_goal_id, created_at DESC);
