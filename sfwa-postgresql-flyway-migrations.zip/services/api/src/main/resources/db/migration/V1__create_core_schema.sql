CREATE TABLE app_user (
    id UUID PRIMARY KEY,
    email VARCHAR(320) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    preferred_currency CHAR(3) NOT NULL DEFAULT 'TND',
    locale VARCHAR(20) NOT NULL DEFAULT 'fr-TN',
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_app_user_email UNIQUE (email),
    CONSTRAINT ck_app_user_email_lowercase CHECK (email = LOWER(email))
);

CREATE TABLE refresh_token (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    replaced_by_token_id UUID REFERENCES refresh_token(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_refresh_token_hash UNIQUE (token_hash)
);

CREATE TABLE category (
    code VARCHAR(60) PRIMARY KEY,
    taxonomy_version VARCHAR(20) NOT NULL,
    direction VARCHAR(10) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT ck_category_direction CHECK (direction IN ('CREDIT', 'DEBIT', 'BOTH'))
);

CREATE TABLE bank_connection (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    provider VARCHAR(60) NOT NULL,
    status VARCHAR(30) NOT NULL,
    scopes TEXT NOT NULL,
    encrypted_access_token TEXT,
    encrypted_refresh_token TEXT,
    token_expires_at TIMESTAMPTZ,
    consent_expires_at TIMESTAMPTZ,
    last_synced_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_bank_connection_status CHECK (status IN ('PENDING', 'ACTIVE', 'EXPIRED', 'REVOKED', 'ERROR'))
);

CREATE INDEX idx_bank_connection_user ON bank_connection(user_id);

CREATE TABLE sync_job (
    id UUID PRIMARY KEY,
    connection_id UUID NOT NULL REFERENCES bank_connection(id) ON DELETE CASCADE,
    status VARCHAR(30) NOT NULL,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    imported_count INTEGER NOT NULL DEFAULT 0,
    duplicate_count INTEGER NOT NULL DEFAULT 0,
    error_code VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_sync_job_status CHECK (status IN ('QUEUED', 'RUNNING', 'SUCCEEDED', 'FAILED')),
    CONSTRAINT ck_sync_job_counts CHECK (imported_count >= 0 AND duplicate_count >= 0)
);

CREATE TABLE bank_account (
    id UUID PRIMARY KEY,
    connection_id UUID NOT NULL REFERENCES bank_connection(id) ON DELETE CASCADE,
    external_account_id VARCHAR(255) NOT NULL,
    name VARCHAR(160) NOT NULL,
    masked_identifier VARCHAR(80) NOT NULL,
    account_type VARCHAR(30) NOT NULL,
    currency CHAR(3) NOT NULL,
    current_balance NUMERIC(19, 4) NOT NULL DEFAULT 0,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_bank_account_external UNIQUE (connection_id, external_account_id),
    CONSTRAINT ck_bank_account_type CHECK (account_type IN ('CHECKING', 'SAVINGS'))
);

CREATE TABLE import_job (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    status VARCHAR(30) NOT NULL,
    original_filename VARCHAR(255) NOT NULL,
    content_hash CHAR(64) NOT NULL,
    proposed_mapping JSONB,
    confirmed_mapping JSONB,
    imported_count INTEGER NOT NULL DEFAULT 0,
    duplicate_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ,
    CONSTRAINT ck_import_job_status CHECK (status IN ('UPLOADED', 'MAPPING_REQUIRED', 'IMPORTING', 'COMPLETED', 'FAILED')),
    CONSTRAINT ck_import_job_counts CHECK (imported_count >= 0 AND duplicate_count >= 0)
);

CREATE TABLE transaction_record (
    id UUID PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    bank_account_id UUID REFERENCES bank_account(id) ON DELETE SET NULL,
    import_job_id UUID REFERENCES import_job(id) ON DELETE SET NULL,
    source_type VARCHAR(10) NOT NULL,
    external_transaction_id VARCHAR(255),
    fingerprint CHAR(64) NOT NULL,
    booking_date DATE NOT NULL,
    value_date DATE,
    amount NUMERIC(19, 4) NOT NULL,
    currency CHAR(3) NOT NULL,
    description VARCHAR(1000) NOT NULL,
    merchant_normalized VARCHAR(255),
    category_code VARCHAR(60) NOT NULL REFERENCES category(code),
    category_confidence NUMERIC(5, 4),
    category_source VARCHAR(30) NOT NULL DEFAULT 'DEFAULT',
    model_version VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_transaction_source CHECK (source_type IN ('BANK', 'FILE')),
    CONSTRAINT ck_transaction_provenance CHECK (
        (source_type = 'BANK' AND bank_account_id IS NOT NULL) OR
        (source_type = 'FILE' AND import_job_id IS NOT NULL)
    ),
    CONSTRAINT ck_category_confidence CHECK (
        category_confidence IS NULL OR category_confidence BETWEEN 0 AND 1
    )
);

CREATE UNIQUE INDEX uk_transaction_bank_external
    ON transaction_record(bank_account_id, external_transaction_id)
    WHERE bank_account_id IS NOT NULL AND external_transaction_id IS NOT NULL;

CREATE UNIQUE INDEX uk_transaction_user_fingerprint
    ON transaction_record(user_id, fingerprint);

CREATE INDEX idx_transaction_user_booking_date
    ON transaction_record(user_id, booking_date DESC);

CREATE TABLE category_feedback (
    id UUID PRIMARY KEY,
    transaction_id UUID NOT NULL REFERENCES transaction_record(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    previous_category_code VARCHAR(60) NOT NULL REFERENCES category(code),
    corrected_category_code VARCHAR(60) NOT NULL REFERENCES category(code),
    previous_confidence NUMERIC(5, 4),
    model_version VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

