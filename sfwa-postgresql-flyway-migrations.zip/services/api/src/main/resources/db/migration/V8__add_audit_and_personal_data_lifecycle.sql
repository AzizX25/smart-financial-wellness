CREATE TABLE audit_log_entry (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_type VARCHAR(20) NOT NULL,
    actor_id UUID,
    action VARCHAR(80) NOT NULL,
    resource_type VARCHAR(80) NOT NULL,
    resource_id UUID,
    outcome VARCHAR(20) NOT NULL,
    change_summary JSONB,
    correlation_id UUID NOT NULL,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_audit_log_actor_type CHECK (actor_type IN ('USER', 'SYSTEM', 'ADMIN', 'SERVICE')),
    CONSTRAINT ck_audit_log_outcome CHECK (outcome IN ('SUCCEEDED', 'FAILED', 'DENIED'))
);

CREATE TABLE personal_data_request (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE RESTRICT,
    request_type VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'REQUESTED',
    requested_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    confirmed_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    failure_reason VARCHAR(1000),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_personal_data_request_type CHECK (request_type IN ('ACCESS', 'EXPORT', 'RECTIFICATION', 'DELETION')),
    CONSTRAINT ck_personal_data_request_status
        CHECK (status IN ('REQUESTED', 'CONFIRMED', 'PROCESSING', 'COMPLETED', 'REJECTED', 'FAILED', 'CANCELLED')),
    CONSTRAINT ck_personal_data_request_dates CHECK (
        (confirmed_at IS NULL OR confirmed_at >= requested_at) AND
        (completed_at IS NULL OR completed_at >= requested_at)
    ),
    CONSTRAINT ck_personal_data_request_failure CHECK (
        status <> 'FAILED' OR failure_reason IS NOT NULL
    )
);

CREATE TABLE personal_data_export (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    personal_data_request_id UUID NOT NULL UNIQUE REFERENCES personal_data_request(id) ON DELETE CASCADE,
    export_format VARCHAR(20) NOT NULL,
    file_reference VARCHAR(500) NOT NULL,
    file_hash CHAR(64) NOT NULL,
    generated_at TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    downloaded_at TIMESTAMPTZ,
    CONSTRAINT ck_personal_data_export_format CHECK (export_format IN ('JSON', 'CSV', 'ZIP')),
    CONSTRAINT ck_personal_data_export_dates CHECK (
        expires_at > generated_at AND
        (downloaded_at IS NULL OR downloaded_at >= generated_at)
    )
);

CREATE TABLE retention_policy (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    data_type VARCHAR(80) NOT NULL,
    policy_version VARCHAR(40) NOT NULL,
    retention_days INTEGER NOT NULL,
    action_at_expiry VARCHAR(20) NOT NULL,
    legal_basis VARCHAR(255),
    active_from DATE NOT NULL,
    active_until DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_retention_policy UNIQUE (data_type, policy_version),
    CONSTRAINT ck_retention_policy_days CHECK (retention_days > 0),
    CONSTRAINT ck_retention_policy_action CHECK (action_at_expiry IN ('DELETE', 'ANONYMIZE', 'ARCHIVE')),
    CONSTRAINT ck_retention_policy_dates CHECK (active_until IS NULL OR active_until >= active_from)
);

CREATE INDEX idx_audit_log_actor_date ON audit_log_entry(actor_id, occurred_at DESC);
CREATE INDEX idx_audit_log_resource_date ON audit_log_entry(resource_type, resource_id, occurred_at DESC);
CREATE INDEX idx_audit_log_correlation ON audit_log_entry(correlation_id);
CREATE INDEX idx_personal_data_request_user_date ON personal_data_request(user_id, requested_at DESC);
CREATE INDEX idx_personal_data_request_status ON personal_data_request(status, requested_at);
