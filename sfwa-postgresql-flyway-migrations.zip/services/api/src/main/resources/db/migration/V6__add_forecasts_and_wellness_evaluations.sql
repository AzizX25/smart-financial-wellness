CREATE TABLE forecast_run (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE RESTRICT,
    monthly_plan_id UUID REFERENCES monthly_plan(id) ON DELETE SET NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'QUEUED',
    forecast_start_date DATE NOT NULL,
    forecast_end_date DATE NOT NULL,
    currency CHAR(3) NOT NULL,
    estimated_final_balance NUMERIC(19, 4),
    final_balance_lower_bound NUMERIC(19, 4),
    final_balance_upper_bound NUMERIC(19, 4),
    deficit_probability NUMERIC(5, 4),
    model_version VARCHAR(100) NOT NULL,
    pipeline_version VARCHAR(100) NOT NULL,
    data_cutoff_at TIMESTAMPTZ NOT NULL,
    model_trained_at TIMESTAMPTZ,
    coverage_rate NUMERIC(5, 4),
    mae NUMERIC(19, 4),
    rmse NUMERIC(19, 4),
    additional_metrics JSONB NOT NULL DEFAULT '{}'::JSONB,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_forecast_run_status CHECK (status IN ('QUEUED', 'RUNNING', 'SUCCEEDED', 'FAILED')),
    CONSTRAINT ck_forecast_run_dates CHECK (forecast_end_date >= forecast_start_date),
    CONSTRAINT ck_forecast_run_currency CHECK (currency = UPPER(currency)),
    CONSTRAINT ck_forecast_run_interval CHECK (
        final_balance_lower_bound IS NULL OR estimated_final_balance IS NULL OR final_balance_upper_bound IS NULL OR
        (final_balance_lower_bound <= estimated_final_balance AND estimated_final_balance <= final_balance_upper_bound)
    ),
    CONSTRAINT ck_forecast_run_probability CHECK (deficit_probability IS NULL OR deficit_probability BETWEEN 0 AND 1),
    CONSTRAINT ck_forecast_run_coverage CHECK (coverage_rate IS NULL OR coverage_rate BETWEEN 0 AND 1),
    CONSTRAINT ck_forecast_run_metrics CHECK ((mae IS NULL OR mae >= 0) AND (rmse IS NULL OR rmse >= 0)),
    CONSTRAINT ck_forecast_run_execution_dates CHECK (
        (completed_at IS NULL OR started_at IS NOT NULL) AND
        (completed_at IS NULL OR completed_at >= started_at)
    )
);

CREATE TABLE forecast_scope (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    forecast_run_id UUID NOT NULL UNIQUE REFERENCES forecast_run(id) ON DELETE CASCADE,
    currency CHAR(3) NOT NULL,
    reference_date DATE NOT NULL,
    CONSTRAINT ck_forecast_scope_currency CHECK (currency = UPPER(currency))
);

CREATE TABLE forecast_scope_account (
    forecast_scope_id UUID NOT NULL REFERENCES forecast_scope(id) ON DELETE CASCADE,
    bank_account_id UUID NOT NULL REFERENCES bank_account(id) ON DELETE RESTRICT,
    reference_balance NUMERIC(19, 4) NOT NULL,
    reference_balance_at TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (forecast_scope_id, bank_account_id)
);

CREATE TABLE forecast_account_result (
    forecast_scope_id UUID NOT NULL,
    bank_account_id UUID NOT NULL,
    estimated_balance NUMERIC(19, 4) NOT NULL,
    lower_bound NUMERIC(19, 4) NOT NULL,
    upper_bound NUMERIC(19, 4) NOT NULL,
    deficit_probability NUMERIC(5, 4) NOT NULL,
    first_deficit_date DATE,
    PRIMARY KEY (forecast_scope_id, bank_account_id),
    CONSTRAINT fk_forecast_account_result_scope
        FOREIGN KEY (forecast_scope_id, bank_account_id)
        REFERENCES forecast_scope_account(forecast_scope_id, bank_account_id)
        ON DELETE CASCADE,
    CONSTRAINT ck_forecast_account_result_interval CHECK (
        lower_bound <= estimated_balance AND estimated_balance <= upper_bound
    ),
    CONSTRAINT ck_forecast_account_result_probability CHECK (deficit_probability BETWEEN 0 AND 1)
);

CREATE TABLE wellness_evaluation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE RESTRICT,
    monthly_plan_id UUID REFERENCES monthly_plan(id) ON DELETE SET NULL,
    forecast_run_id UUID REFERENCES forecast_run(id) ON DELETE SET NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    currency CHAR(3) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
    global_score NUMERIC(5, 2),
    level VARCHAR(20),
    coverage_rate NUMERIC(5, 4) NOT NULL DEFAULT 0,
    method_version VARCHAR(100) NOT NULL,
    produced_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_wellness_evaluation_dates CHECK (period_end >= period_start),
    CONSTRAINT ck_wellness_evaluation_currency CHECK (currency = UPPER(currency)),
    CONSTRAINT ck_wellness_evaluation_status CHECK (status IN ('DRAFT', 'PRODUCED', 'OBSOLETE', 'FAILED')),
    CONSTRAINT ck_wellness_evaluation_score CHECK (global_score IS NULL OR global_score BETWEEN 0 AND 100),
    CONSTRAINT ck_wellness_evaluation_level CHECK (level IS NULL OR level IN ('CRITICAL', 'FRAGILE', 'STABLE', 'GOOD', 'EXCELLENT')),
    CONSTRAINT ck_wellness_evaluation_coverage CHECK (coverage_rate BETWEEN 0 AND 1),
    CONSTRAINT ck_wellness_evaluation_produced CHECK (
        status NOT IN ('PRODUCED', 'OBSOLETE') OR
        (global_score IS NOT NULL AND level IS NOT NULL AND produced_at IS NOT NULL)
    )
);

CREATE TABLE wellness_evaluation_account (
    wellness_evaluation_id UUID NOT NULL REFERENCES wellness_evaluation(id) ON DELETE CASCADE,
    bank_account_id UUID NOT NULL REFERENCES bank_account(id) ON DELETE RESTRICT,
    PRIMARY KEY (wellness_evaluation_id, bank_account_id)
);

CREATE TABLE evaluation_dimension (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wellness_evaluation_id UUID NOT NULL REFERENCES wellness_evaluation(id) ON DELETE CASCADE,
    dimension_type VARCHAR(40) NOT NULL,
    score NUMERIC(5, 2) NOT NULL,
    weight NUMERIC(5, 4) NOT NULL,
    coverage_rate NUMERIC(5, 4) NOT NULL,
    CONSTRAINT uk_evaluation_dimension UNIQUE (wellness_evaluation_id, dimension_type),
    CONSTRAINT ck_evaluation_dimension_type CHECK (
        dimension_type IN ('MONTHLY_BALANCE', 'BUDGET_ADHERENCE', 'FINANCIAL_SAFETY', 'SAVINGS_AND_GOALS', 'SHORT_TERM_OUTLOOK')
    ),
    CONSTRAINT ck_evaluation_dimension_score CHECK (score BETWEEN 0 AND 100),
    CONSTRAINT ck_evaluation_dimension_weight CHECK (weight BETWEEN 0 AND 1),
    CONSTRAINT ck_evaluation_dimension_coverage CHECK (coverage_rate BETWEEN 0 AND 1)
);

CREATE TABLE evaluation_indicator (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    evaluation_dimension_id UUID NOT NULL REFERENCES evaluation_dimension(id) ON DELETE CASCADE,
    indicator_code VARCHAR(80) NOT NULL,
    numeric_value NUMERIC(19, 6),
    unit VARCHAR(30),
    level VARCHAR(20),
    explanation VARCHAR(1000) NOT NULL,
    data_source VARCHAR(100) NOT NULL,
    calculable BOOLEAN NOT NULL,
    unavailable_reason VARCHAR(500),
    CONSTRAINT uk_evaluation_indicator UNIQUE (evaluation_dimension_id, indicator_code),
    CONSTRAINT ck_evaluation_indicator_level
        CHECK (level IS NULL OR level IN ('CRITICAL', 'WARNING', 'NEUTRAL', 'POSITIVE', 'EXCELLENT')),
    CONSTRAINT ck_evaluation_indicator_availability CHECK (
        (calculable = TRUE AND unavailable_reason IS NULL) OR
        (calculable = FALSE AND unavailable_reason IS NOT NULL)
    )
);

CREATE INDEX idx_forecast_run_user_date ON forecast_run(user_id, completed_at DESC);
CREATE INDEX idx_forecast_scope_account_account ON forecast_scope_account(bank_account_id);
CREATE INDEX idx_wellness_evaluation_user_date ON wellness_evaluation(user_id, produced_at DESC);
CREATE INDEX idx_wellness_evaluation_account_account ON wellness_evaluation_account(bank_account_id);
CREATE INDEX idx_evaluation_dimension_evaluation ON evaluation_dimension(wellness_evaluation_id);
CREATE INDEX idx_evaluation_indicator_dimension ON evaluation_indicator(evaluation_dimension_id);

-- Forecast simulations are intentionally absent: their assumptions and results are transient API data.
