CREATE OR REPLACE FUNCTION set_updated_at_and_version()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at := CURRENT_TIMESTAMP;
    NEW.version := OLD.version + 1;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_app_user_updated
    BEFORE UPDATE ON app_user
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_user_profile_updated
    BEFORE UPDATE ON user_profile
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_interface_preference_updated
    BEFORE UPDATE ON interface_preference
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_financial_preference_updated
    BEFORE UPDATE ON financial_preference
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_user_consent_updated
    BEFORE UPDATE ON user_consent
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_bank_account_updated
    BEFORE UPDATE ON bank_account
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_transaction_record_updated
    BEFORE UPDATE ON transaction_record
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_monthly_plan_updated
    BEFORE UPDATE ON monthly_plan
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_planned_income_updated
    BEFORE UPDATE ON planned_income
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_budget_allocation_updated
    BEFORE UPDATE ON budget_allocation
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_financial_goal_updated
    BEFORE UPDATE ON financial_goal
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_goal_allocation_updated
    BEFORE UPDATE ON goal_allocation
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_goal_scenario_updated
    BEFORE UPDATE ON goal_scenario
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_wellness_evaluation_updated
    BEFORE UPDATE ON wellness_evaluation
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_personalized_recommendation_updated
    BEFORE UPDATE ON personalized_recommendation
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_financial_alert_updated
    BEFORE UPDATE ON financial_alert
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_notification_preference_updated
    BEFORE UPDATE ON notification_preference
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_notification_destination_updated
    BEFORE UPDATE ON notification_destination
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_dashboard_scope_updated
    BEFORE UPDATE ON dashboard_scope
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_dashboard_card_preference_updated
    BEFORE UPDATE ON dashboard_card_preference
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();
CREATE TRIGGER trg_personal_data_request_updated
    BEFORE UPDATE ON personal_data_request
    FOR EACH ROW EXECUTE FUNCTION set_updated_at_and_version();

CREATE OR REPLACE FUNCTION validate_bank_account_owner()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    connection_user_id UUID;
BEGIN
    IF NEW.connection_id IS NOT NULL THEN
        SELECT user_id INTO connection_user_id
        FROM bank_connection
        WHERE id = NEW.connection_id;

        IF connection_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Bank account and connection must belong to the same user'
                USING ERRCODE = '23514';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_bank_account_owner
    BEFORE INSERT OR UPDATE OF connection_id, user_id ON bank_account
    FOR EACH ROW EXECUTE FUNCTION validate_bank_account_owner();

CREATE OR REPLACE FUNCTION validate_import_job_owner()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    account_user_id UUID;
BEGIN
    IF NEW.bank_account_id IS NOT NULL THEN
        SELECT user_id INTO account_user_id
        FROM bank_account
        WHERE id = NEW.bank_account_id;

        IF account_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Import job and target account must belong to the same user'
                USING ERRCODE = '23514';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_import_job_owner
    BEFORE INSERT OR UPDATE OF bank_account_id, user_id ON import_job
    FOR EACH ROW EXECUTE FUNCTION validate_import_job_owner();

CREATE OR REPLACE FUNCTION validate_transaction_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    related_user_id UUID;
    account_connection_id UUID;
    job_connection_id UUID;
    category_user_id UUID;
    category_scope VARCHAR(20);
BEGIN
    IF NEW.bank_account_id IS NOT NULL THEN
        SELECT user_id, connection_id
        INTO related_user_id, account_connection_id
        FROM bank_account
        WHERE id = NEW.bank_account_id;

        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Transaction and account must belong to the same user'
                USING ERRCODE = '23514';
        END IF;
    END IF;

    IF NEW.import_job_id IS NOT NULL THEN
        SELECT user_id INTO related_user_id
        FROM import_job
        WHERE id = NEW.import_job_id;

        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Transaction and import job must belong to the same user'
                USING ERRCODE = '23514';
        END IF;
    END IF;

    IF NEW.sync_job_id IS NOT NULL THEN
        SELECT c.user_id, j.connection_id
        INTO related_user_id, job_connection_id
        FROM sync_job j
        JOIN bank_connection c ON c.id = j.connection_id
        WHERE j.id = NEW.sync_job_id;

        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Transaction and synchronization job must belong to the same user'
                USING ERRCODE = '23514';
        END IF;

        IF NEW.bank_account_id IS NOT NULL AND account_connection_id IS DISTINCT FROM job_connection_id THEN
            RAISE EXCEPTION 'Synchronized transaction account must belong to the synchronized connection'
                USING ERRCODE = '23514';
        END IF;
    END IF;

    SELECT user_id, scope INTO category_user_id, category_scope
    FROM category
    WHERE code = NEW.category_code;

    IF category_scope = 'USER' AND category_user_id IS DISTINCT FROM NEW.user_id THEN
        RAISE EXCEPTION 'A user category cannot classify another user''s transaction'
            USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_transaction_ownership
    BEFORE INSERT OR UPDATE OF user_id, bank_account_id, import_job_id, sync_job_id, category_code
    ON transaction_record
    FOR EACH ROW EXECUTE FUNCTION validate_transaction_ownership();

CREATE OR REPLACE FUNCTION validate_category_feedback_owner()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    transaction_user_id UUID;
    corrected_category_user_id UUID;
BEGIN
    SELECT user_id INTO transaction_user_id
    FROM transaction_record
    WHERE id = NEW.transaction_id;

    IF transaction_user_id IS DISTINCT FROM NEW.user_id THEN
        RAISE EXCEPTION 'Category correction and transaction must belong to the same user'
            USING ERRCODE = '23514';
    END IF;

    SELECT user_id INTO corrected_category_user_id
    FROM category
    WHERE code = NEW.corrected_category_code;

    IF corrected_category_user_id IS NOT NULL AND corrected_category_user_id IS DISTINCT FROM NEW.user_id THEN
        RAISE EXCEPTION 'A user cannot select another user''s category'
            USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_category_feedback_owner
    BEFORE INSERT OR UPDATE ON category_feedback
    FOR EACH ROW EXECUTE FUNCTION validate_category_feedback_owner();

CREATE OR REPLACE FUNCTION validate_budget_allocation_category()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    plan_user_id UUID;
    category_user_id UUID;
BEGIN
    SELECT user_id INTO plan_user_id FROM monthly_plan WHERE id = NEW.monthly_plan_id;
    SELECT user_id INTO category_user_id FROM category WHERE code = NEW.category_code;

    IF category_user_id IS NOT NULL AND category_user_id IS DISTINCT FROM plan_user_id THEN
        RAISE EXCEPTION 'A monthly plan cannot use another user''s category'
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_budget_allocation_category
    BEFORE INSERT OR UPDATE ON budget_allocation
    FOR EACH ROW EXECUTE FUNCTION validate_budget_allocation_category();

CREATE OR REPLACE FUNCTION validate_goal_allocation_compatibility()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    plan_user_id UUID;
    plan_currency CHAR(3);
    goal_user_id UUID;
    goal_currency CHAR(3);
BEGIN
    SELECT user_id, currency INTO plan_user_id, plan_currency
    FROM monthly_plan WHERE id = NEW.monthly_plan_id;

    SELECT user_id, currency INTO goal_user_id, goal_currency
    FROM financial_goal WHERE id = NEW.financial_goal_id;

    IF plan_user_id IS DISTINCT FROM goal_user_id OR plan_currency IS DISTINCT FROM goal_currency THEN
        RAISE EXCEPTION 'Goal allocation requires the same user and currency for plan and goal'
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_goal_allocation_compatibility
    BEFORE INSERT OR UPDATE ON goal_allocation
    FOR EACH ROW EXECUTE FUNCTION validate_goal_allocation_compatibility();

CREATE OR REPLACE FUNCTION validate_goal_contribution_compatibility()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    goal_user_id UUID;
    goal_currency CHAR(3);
    transaction_user_id UUID;
    transaction_currency CHAR(3);
BEGIN
    IF NEW.transaction_id IS NULL THEN
        RETURN NEW;
    END IF;

    SELECT user_id, currency INTO goal_user_id, goal_currency
    FROM financial_goal WHERE id = NEW.financial_goal_id;

    SELECT user_id, currency INTO transaction_user_id, transaction_currency
    FROM transaction_record WHERE id = NEW.transaction_id;

    IF goal_user_id IS DISTINCT FROM transaction_user_id OR goal_currency IS DISTINCT FROM transaction_currency THEN
        RAISE EXCEPTION 'Goal contribution transaction requires the same user and currency as the goal'
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_goal_contribution_compatibility
    BEFORE INSERT OR UPDATE ON goal_contribution
    FOR EACH ROW EXECUTE FUNCTION validate_goal_contribution_compatibility();

CREATE OR REPLACE FUNCTION validate_forecast_scope_account()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    run_user_id UUID;
    scope_currency CHAR(3);
    account_user_id UUID;
    account_currency CHAR(3);
BEGIN
    SELECT r.user_id, s.currency INTO run_user_id, scope_currency
    FROM forecast_scope s
    JOIN forecast_run r ON r.id = s.forecast_run_id
    WHERE s.id = NEW.forecast_scope_id;

    SELECT user_id, currency INTO account_user_id, account_currency
    FROM bank_account WHERE id = NEW.bank_account_id;

    IF run_user_id IS DISTINCT FROM account_user_id OR scope_currency IS DISTINCT FROM account_currency THEN
        RAISE EXCEPTION 'Forecast scope account requires the same user and currency as the forecast'
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_forecast_scope_account
    BEFORE INSERT OR UPDATE ON forecast_scope_account
    FOR EACH ROW EXECUTE FUNCTION validate_forecast_scope_account();

CREATE OR REPLACE FUNCTION validate_wellness_evaluation_account()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    evaluation_user_id UUID;
    evaluation_currency CHAR(3);
    account_user_id UUID;
    account_currency CHAR(3);
BEGIN
    SELECT user_id, currency INTO evaluation_user_id, evaluation_currency
    FROM wellness_evaluation WHERE id = NEW.wellness_evaluation_id;

    SELECT user_id, currency INTO account_user_id, account_currency
    FROM bank_account WHERE id = NEW.bank_account_id;

    IF evaluation_user_id IS DISTINCT FROM account_user_id OR evaluation_currency IS DISTINCT FROM account_currency THEN
        RAISE EXCEPTION 'Evaluation account requires the same user and currency as the evaluation'
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_wellness_evaluation_account
    BEFORE INSERT OR UPDATE ON wellness_evaluation_account
    FOR EACH ROW EXECUTE FUNCTION validate_wellness_evaluation_account();

CREATE OR REPLACE FUNCTION validate_dashboard_scope_account()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    scope_user_id UUID;
    scope_currency CHAR(3);
    account_user_id UUID;
    account_currency CHAR(3);
BEGIN
    SELECT user_id, display_currency INTO scope_user_id, scope_currency
    FROM dashboard_scope WHERE id = NEW.dashboard_scope_id;

    SELECT user_id, currency INTO account_user_id, account_currency
    FROM bank_account WHERE id = NEW.bank_account_id;

    IF scope_user_id IS DISTINCT FROM account_user_id OR scope_currency IS DISTINCT FROM account_currency THEN
        RAISE EXCEPTION 'Dashboard account requires the same user and display currency as the dashboard scope'
            USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_dashboard_scope_account
    BEFORE INSERT OR UPDATE ON dashboard_scope_account
    FOR EACH ROW EXECUTE FUNCTION validate_dashboard_scope_account();

CREATE OR REPLACE FUNCTION validate_internal_transfer()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    outgoing_user_id UUID;
    outgoing_currency CHAR(3);
    outgoing_direction VARCHAR(10);
    incoming_user_id UUID;
    incoming_currency CHAR(3);
    incoming_direction VARCHAR(10);
BEGIN
    SELECT user_id, currency, direction
    INTO outgoing_user_id, outgoing_currency, outgoing_direction
    FROM transaction_record WHERE id = NEW.outgoing_transaction_id;

    SELECT user_id, currency, direction
    INTO incoming_user_id, incoming_currency, incoming_direction
    FROM transaction_record WHERE id = NEW.incoming_transaction_id;

    IF outgoing_user_id IS DISTINCT FROM incoming_user_id OR outgoing_currency IS DISTINCT FROM incoming_currency THEN
        RAISE EXCEPTION 'Internal transfer transactions require the same user and currency'
            USING ERRCODE = '23514';
    END IF;

    IF outgoing_direction <> 'DEBIT' OR incoming_direction <> 'CREDIT' THEN
        RAISE EXCEPTION 'Internal transfer requires one outgoing debit and one incoming credit'
            USING ERRCODE = '23514';
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_internal_transfer
    BEFORE INSERT OR UPDATE ON internal_transfer
    FOR EACH ROW EXECUTE FUNCTION validate_internal_transfer();

CREATE OR REPLACE FUNCTION synchronize_internal_transfer_flags()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        UPDATE transaction_record SET internal_transfer = FALSE
        WHERE id IN (OLD.outgoing_transaction_id, OLD.incoming_transaction_id);
        RETURN OLD;
    END IF;

    UPDATE transaction_record SET internal_transfer = TRUE
    WHERE id IN (NEW.outgoing_transaction_id, NEW.incoming_transaction_id);

    IF TG_OP = 'UPDATE' THEN
        UPDATE transaction_record SET internal_transfer = FALSE
        WHERE id IN (OLD.outgoing_transaction_id, OLD.incoming_transaction_id)
          AND id NOT IN (NEW.outgoing_transaction_id, NEW.incoming_transaction_id);
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_synchronize_internal_transfer_flags
    AFTER INSERT OR UPDATE OR DELETE ON internal_transfer
    FOR EACH ROW EXECUTE FUNCTION synchronize_internal_transfer_flags();

CREATE OR REPLACE FUNCTION check_confirmed_goal_allocation_total()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    affected_plan_id UUID;
    saving_capacity NUMERIC(19, 4);
    allocated_total NUMERIC(19, 4);
BEGIN
    affected_plan_id := CASE WHEN TG_OP = 'DELETE' THEN OLD.monthly_plan_id ELSE NEW.monthly_plan_id END;

    SELECT calculated_saving_capacity INTO saving_capacity
    FROM monthly_plan WHERE id = affected_plan_id;

    SELECT COALESCE(SUM(confirmed_amount), 0) INTO allocated_total
    FROM goal_allocation
    WHERE monthly_plan_id = affected_plan_id AND status = 'CONFIRMED';

    IF allocated_total > saving_capacity THEN
        RAISE EXCEPTION 'Confirmed goal allocations exceed the monthly saving capacity'
            USING ERRCODE = '23514';
    END IF;

    RETURN NULL;
END;
$$;

CREATE CONSTRAINT TRIGGER trg_check_confirmed_goal_allocation_total
    AFTER INSERT OR UPDATE OR DELETE ON goal_allocation
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW EXECUTE FUNCTION check_confirmed_goal_allocation_total();

CREATE OR REPLACE FUNCTION check_monthly_plan_allocation_capacity()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    allocated_total NUMERIC(19, 4);
BEGIN
    SELECT COALESCE(SUM(confirmed_amount), 0) INTO allocated_total
    FROM goal_allocation
    WHERE monthly_plan_id = NEW.id AND status = 'CONFIRMED';

    IF allocated_total > NEW.calculated_saving_capacity THEN
        RAISE EXCEPTION 'Monthly saving capacity cannot be lower than confirmed goal allocations'
            USING ERRCODE = '23514';
    END IF;
    RETURN NULL;
END;
$$;

CREATE CONSTRAINT TRIGGER trg_check_monthly_plan_allocation_capacity
    AFTER UPDATE OF calculated_saving_capacity ON monthly_plan
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW EXECUTE FUNCTION check_monthly_plan_allocation_capacity();

CREATE OR REPLACE FUNCTION guard_evaluation_root_immutability()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF OLD.status NOT IN ('PRODUCED', 'OBSOLETE') THEN
        IF TG_OP = 'DELETE' THEN
            RETURN OLD;
        END IF;
        RETURN NEW;
    END IF;

    IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'A produced wellness evaluation is immutable'
            USING ERRCODE = '23514';
    END IF;

    IF OLD.status = 'PRODUCED'
       AND NEW.status = 'OBSOLETE'
       AND ROW(
           NEW.id, NEW.user_id, NEW.monthly_plan_id, NEW.forecast_run_id,
           NEW.period_start, NEW.period_end, NEW.currency, NEW.global_score,
           NEW.level, NEW.coverage_rate, NEW.method_version, NEW.produced_at, NEW.created_at
       ) IS NOT DISTINCT FROM ROW(
           OLD.id, OLD.user_id, OLD.monthly_plan_id, OLD.forecast_run_id,
           OLD.period_start, OLD.period_end, OLD.currency, OLD.global_score,
           OLD.level, OLD.coverage_rate, OLD.method_version, OLD.produced_at, OLD.created_at
       ) THEN
        RETURN NEW;
    END IF;

    RAISE EXCEPTION 'A produced wellness evaluation is immutable; only PRODUCED to OBSOLETE is allowed'
        USING ERRCODE = '23514';
END;
$$;

CREATE TRIGGER trg_a_guard_evaluation_root_immutability
    BEFORE UPDATE OR DELETE ON wellness_evaluation
    FOR EACH ROW EXECUTE FUNCTION guard_evaluation_root_immutability();

CREATE OR REPLACE FUNCTION validate_evaluation_publication()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    dimension_count INTEGER;
    dimension_without_indicator_count INTEGER;
    total_weight NUMERIC;
BEGIN
    IF TG_OP = 'INSERT' AND NEW.status IN ('PRODUCED', 'OBSOLETE') THEN
        RAISE EXCEPTION 'Create an evaluation as DRAFT, add dimensions and indicators, then publish it'
            USING ERRCODE = '23514';
    END IF;

    IF TG_OP = 'UPDATE' AND NEW.status = 'PRODUCED' AND OLD.status <> 'PRODUCED' THEN
        SELECT COUNT(*), COALESCE(SUM(weight), 0)
        INTO dimension_count, total_weight
        FROM evaluation_dimension
        WHERE wellness_evaluation_id = NEW.id;

        SELECT COUNT(*) INTO dimension_without_indicator_count
        FROM evaluation_dimension d
        WHERE d.wellness_evaluation_id = NEW.id
          AND NOT EXISTS (
              SELECT 1 FROM evaluation_indicator i WHERE i.evaluation_dimension_id = d.id
          );

        IF dimension_count = 0 OR dimension_without_indicator_count > 0 THEN
            RAISE EXCEPTION 'A produced evaluation requires dimensions and at least one indicator per dimension'
                USING ERRCODE = '23514';
        END IF;

        IF ABS(total_weight - 1) > 0.0001 THEN
            RAISE EXCEPTION 'Evaluation dimension weights must sum to 1'
                USING ERRCODE = '23514';
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_b_validate_evaluation_publication
    BEFORE INSERT OR UPDATE ON wellness_evaluation
    FOR EACH ROW EXECUTE FUNCTION validate_evaluation_publication();

CREATE OR REPLACE FUNCTION guard_evaluation_child_immutability()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    old_evaluation_id UUID;
    new_evaluation_id UUID;
    evaluation_status VARCHAR(20);
BEGIN
    IF TG_TABLE_NAME = 'evaluation_dimension' THEN
        IF TG_OP IN ('UPDATE', 'DELETE') THEN
            old_evaluation_id := OLD.wellness_evaluation_id;
        END IF;
        IF TG_OP IN ('INSERT', 'UPDATE') THEN
            new_evaluation_id := NEW.wellness_evaluation_id;
        END IF;
    ELSE
        IF TG_OP IN ('UPDATE', 'DELETE') THEN
            SELECT wellness_evaluation_id INTO old_evaluation_id
            FROM evaluation_dimension WHERE id = OLD.evaluation_dimension_id;
        END IF;
        IF TG_OP IN ('INSERT', 'UPDATE') THEN
            SELECT wellness_evaluation_id INTO new_evaluation_id
            FROM evaluation_dimension WHERE id = NEW.evaluation_dimension_id;
        END IF;
    END IF;

    IF old_evaluation_id IS NOT NULL THEN
        SELECT status INTO evaluation_status
        FROM wellness_evaluation WHERE id = old_evaluation_id;

        IF evaluation_status IN ('PRODUCED', 'OBSOLETE') THEN
            RAISE EXCEPTION 'Dimensions and indicators of a produced evaluation are immutable'
                USING ERRCODE = '23514';
        END IF;
    END IF;

    IF new_evaluation_id IS NOT NULL AND new_evaluation_id IS DISTINCT FROM old_evaluation_id THEN
        SELECT status INTO evaluation_status
        FROM wellness_evaluation WHERE id = new_evaluation_id;

        IF evaluation_status IN ('PRODUCED', 'OBSOLETE') THEN
            RAISE EXCEPTION 'Dimensions and indicators of a produced evaluation are immutable'
                USING ERRCODE = '23514';
        END IF;
    END IF;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_guard_evaluation_dimension_immutability
    BEFORE INSERT OR UPDATE OR DELETE ON evaluation_dimension
    FOR EACH ROW EXECUTE FUNCTION guard_evaluation_child_immutability();
CREATE TRIGGER trg_guard_evaluation_indicator_immutability
    BEFORE INSERT OR UPDATE OR DELETE ON evaluation_indicator
    FOR EACH ROW EXECUTE FUNCTION guard_evaluation_child_immutability();

CREATE OR REPLACE FUNCTION validate_recommendation_ownership_and_activation()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    evaluation_user_id UUID;
    justification_count INTEGER;
BEGIN
    SELECT user_id INTO evaluation_user_id
    FROM wellness_evaluation WHERE id = NEW.wellness_evaluation_id;

    IF evaluation_user_id IS DISTINCT FROM NEW.user_id THEN
        RAISE EXCEPTION 'Recommendation and evaluation must belong to the same user'
            USING ERRCODE = '23514';
    END IF;

    IF TG_OP = 'INSERT' AND NEW.status = 'ACTIVE' THEN
        RAISE EXCEPTION 'Create a recommendation as DRAFT, add a justification, then activate it'
            USING ERRCODE = '23514';
    END IF;

    IF TG_OP = 'UPDATE' AND NEW.status = 'ACTIVE' AND OLD.status <> 'ACTIVE' THEN
        SELECT COUNT(*) INTO justification_count
        FROM recommendation_justification WHERE recommendation_id = NEW.id;

        IF justification_count = 0 THEN
            RAISE EXCEPTION 'An active recommendation requires at least one justification'
                USING ERRCODE = '23514';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_recommendation_ownership_and_activation
    BEFORE INSERT OR UPDATE ON personalized_recommendation
    FOR EACH ROW EXECUTE FUNCTION validate_recommendation_ownership_and_activation();

CREATE OR REPLACE FUNCTION check_active_recommendation_justification()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    affected_recommendation_id UUID;
    recommendation_status VARCHAR(20);
    justification_count INTEGER;
BEGIN
    affected_recommendation_id := CASE
        WHEN TG_OP = 'DELETE' THEN OLD.recommendation_id
        ELSE NEW.recommendation_id
    END;

    SELECT status INTO recommendation_status
    FROM personalized_recommendation
    WHERE id = affected_recommendation_id;

    IF recommendation_status = 'ACTIVE' THEN
        SELECT COUNT(*) INTO justification_count
        FROM recommendation_justification
        WHERE recommendation_id = affected_recommendation_id;

        IF justification_count = 0 THEN
            RAISE EXCEPTION 'An active recommendation must keep at least one justification'
                USING ERRCODE = '23514';
        END IF;
    END IF;

    RETURN NULL;
END;
$$;

CREATE CONSTRAINT TRIGGER trg_check_active_recommendation_justification
    AFTER INSERT OR UPDATE OR DELETE ON recommendation_justification
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW EXECUTE FUNCTION check_active_recommendation_justification();

CREATE OR REPLACE FUNCTION validate_financial_alert_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    related_user_id UUID;
BEGIN
    IF NEW.forecast_run_id IS NOT NULL THEN
        SELECT user_id INTO related_user_id FROM forecast_run WHERE id = NEW.forecast_run_id;
        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Alert and forecast must belong to the same user' USING ERRCODE = '23514';
        END IF;
    END IF;
    IF NEW.monthly_plan_id IS NOT NULL THEN
        SELECT user_id INTO related_user_id FROM monthly_plan WHERE id = NEW.monthly_plan_id;
        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Alert and monthly plan must belong to the same user' USING ERRCODE = '23514';
        END IF;
    END IF;
    IF NEW.financial_goal_id IS NOT NULL THEN
        SELECT user_id INTO related_user_id FROM financial_goal WHERE id = NEW.financial_goal_id;
        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Alert and goal must belong to the same user' USING ERRCODE = '23514';
        END IF;
    END IF;
    IF NEW.bank_account_id IS NOT NULL THEN
        SELECT user_id INTO related_user_id FROM bank_account WHERE id = NEW.bank_account_id;
        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Alert and account must belong to the same user' USING ERRCODE = '23514';
        END IF;
    END IF;
    IF NEW.recommendation_id IS NOT NULL THEN
        SELECT user_id INTO related_user_id FROM personalized_recommendation WHERE id = NEW.recommendation_id;
        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Alert and recommendation must belong to the same user' USING ERRCODE = '23514';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_financial_alert_ownership
    BEFORE INSERT OR UPDATE ON financial_alert
    FOR EACH ROW EXECUTE FUNCTION validate_financial_alert_ownership();

CREATE OR REPLACE FUNCTION validate_notification_ownership()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    related_user_id UUID;
BEGIN
    IF NEW.financial_alert_id IS NOT NULL THEN
        SELECT user_id INTO related_user_id FROM financial_alert WHERE id = NEW.financial_alert_id;
        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Notification and alert must belong to the same user' USING ERRCODE = '23514';
        END IF;
    END IF;
    IF NEW.recommendation_id IS NOT NULL THEN
        SELECT user_id INTO related_user_id FROM personalized_recommendation WHERE id = NEW.recommendation_id;
        IF related_user_id IS DISTINCT FROM NEW.user_id THEN
            RAISE EXCEPTION 'Notification and recommendation must belong to the same user' USING ERRCODE = '23514';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_validate_notification_ownership
    BEFORE INSERT OR UPDATE ON user_notification
    FOR EACH ROW EXECUTE FUNCTION validate_notification_ownership();

CREATE INDEX idx_transaction_description_normalized
    ON transaction_record(merchant_normalized)
    WHERE merchant_normalized IS NOT NULL;
CREATE INDEX idx_forecast_run_status ON forecast_run(status, created_at);
CREATE INDEX idx_wellness_evaluation_status ON wellness_evaluation(status, created_at);
CREATE INDEX idx_security_event_type_date ON security_event(event_type, detected_at DESC);
