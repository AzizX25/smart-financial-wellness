CREATE TABLE personalized_recommendation (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE RESTRICT,
    wellness_evaluation_id UUID NOT NULL REFERENCES wellness_evaluation(id) ON DELETE RESTRICT,
    recommendation_type VARCHAR(50) NOT NULL,
    title VARCHAR(200) NOT NULL,
    message VARCHAR(2000) NOT NULL,
    priority VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'DRAFT',
    proposed_action_type VARCHAR(50),
    action_parameters JSONB,
    rules_version VARCHAR(100) NOT NULL,
    llm_version VARCHAR(100),
    confidence NUMERIC(5, 4),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ,
    closed_at TIMESTAMPTZ,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_personalized_recommendation_priority CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_personalized_recommendation_status CHECK (status IN ('DRAFT', 'ACTIVE', 'ACCEPTED', 'REJECTED', 'HIDDEN', 'OBSOLETE', 'EXPIRED')),
    CONSTRAINT ck_personalized_recommendation_confidence CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),
    CONSTRAINT ck_personalized_recommendation_expiry CHECK (expires_at IS NULL OR expires_at > created_at),
    CONSTRAINT ck_personalized_recommendation_close CHECK (closed_at IS NULL OR closed_at >= created_at),
    CONSTRAINT ck_personalized_recommendation_action CHECK (
        (proposed_action_type IS NULL AND action_parameters IS NULL) OR proposed_action_type IS NOT NULL
    )
);

CREATE TABLE recommendation_justification (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recommendation_id UUID NOT NULL REFERENCES personalized_recommendation(id) ON DELETE CASCADE,
    evaluation_indicator_id UUID REFERENCES evaluation_indicator(id) ON DELETE RESTRICT,
    justification_type VARCHAR(40) NOT NULL,
    factual_message VARCHAR(1000) NOT NULL,
    importance NUMERIC(5, 4) NOT NULL DEFAULT 1,
    CONSTRAINT ck_recommendation_justification_importance CHECK (importance BETWEEN 0 AND 1)
);

CREATE TABLE recommendation_interaction (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recommendation_id UUID NOT NULL REFERENCES personalized_recommendation(id) ON DELETE CASCADE,
    interaction_type VARCHAR(30) NOT NULL,
    occurred_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_recommendation_interaction_type CHECK (
        interaction_type IN ('DISPLAYED', 'OPENED', 'ACCEPTED', 'REJECTED', 'HIDDEN', 'ACTION_PROPOSED', 'ACTION_CONFIRMED')
    )
);

CREATE TABLE financial_alert (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE RESTRICT,
    forecast_run_id UUID REFERENCES forecast_run(id) ON DELETE SET NULL,
    monthly_plan_id UUID REFERENCES monthly_plan(id) ON DELETE SET NULL,
    financial_goal_id UUID REFERENCES financial_goal(id) ON DELETE SET NULL,
    bank_account_id UUID REFERENCES bank_account(id) ON DELETE SET NULL,
    recommendation_id UUID UNIQUE REFERENCES personalized_recommendation(id) ON DELETE SET NULL,
    alert_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    title VARCHAR(200) NOT NULL,
    message VARCHAR(2000) NOT NULL,
    deduplication_key VARCHAR(255) NOT NULL,
    first_detected_at TIMESTAMPTZ NOT NULL,
    last_detected_at TIMESTAMPTZ NOT NULL,
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_financial_alert_severity CHECK (severity IN ('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_financial_alert_status CHECK (status IN ('OPEN', 'ACKNOWLEDGED', 'RESOLVED', 'DISMISSED')),
    CONSTRAINT ck_financial_alert_dates CHECK (
        last_detected_at >= first_detected_at AND
        (resolved_at IS NULL OR resolved_at >= first_detected_at)
    )
);

CREATE UNIQUE INDEX uk_financial_alert_active_deduplication
    ON financial_alert(user_id, deduplication_key)
    WHERE status IN ('OPEN', 'ACKNOWLEDGED');

CREATE TABLE alert_occurrence (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    financial_alert_id UUID NOT NULL REFERENCES financial_alert(id) ON DELETE CASCADE,
    observed_value NUMERIC(19, 6),
    threshold_value NUMERIC(19, 6),
    details JSONB NOT NULL DEFAULT '{}'::JSONB,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notification_preference (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    event_type VARCHAR(60) NOT NULL,
    channel VARCHAR(20) NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    minimum_priority VARCHAR(20) NOT NULL DEFAULT 'LOW',
    quiet_hours_start TIME,
    quiet_hours_end TIME,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT uk_notification_preference UNIQUE (user_id, event_type, channel),
    CONSTRAINT ck_notification_preference_channel CHECK (channel IN ('IN_APP', 'EMAIL', 'PUSH')),
    CONSTRAINT ck_notification_preference_priority CHECK (minimum_priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_notification_preference_quiet_hours CHECK (
        (quiet_hours_start IS NULL AND quiet_hours_end IS NULL) OR
        (quiet_hours_start IS NOT NULL AND quiet_hours_end IS NOT NULL)
    )
);

CREATE TABLE notification_destination (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    channel VARCHAR(20) NOT NULL,
    masked_destination VARCHAR(255) NOT NULL,
    encrypted_destination TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    verified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT uk_notification_destination UNIQUE (user_id, channel),
    CONSTRAINT ck_notification_destination_channel CHECK (channel IN ('EMAIL', 'PUSH')),
    CONSTRAINT ck_notification_destination_status CHECK (status IN ('PENDING', 'VERIFIED', 'DISABLED')),
    CONSTRAINT ck_notification_destination_verification CHECK (
        status <> 'VERIFIED' OR verified_at IS NOT NULL
    )
);

CREATE TABLE user_notification (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    financial_alert_id UUID REFERENCES financial_alert(id) ON DELETE SET NULL,
    recommendation_id UUID REFERENCES personalized_recommendation(id) ON DELETE SET NULL,
    notification_type VARCHAR(60) NOT NULL,
    title VARCHAR(200) NOT NULL,
    message VARCHAR(2000) NOT NULL,
    priority VARCHAR(20) NOT NULL,
    deduplication_key VARCHAR(255) NOT NULL,
    read_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_user_notification_deduplication UNIQUE (user_id, deduplication_key),
    CONSTRAINT ck_user_notification_priority CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    CONSTRAINT ck_user_notification_source CHECK (NUM_NONNULLS(financial_alert_id, recommendation_id) <= 1),
    CONSTRAINT ck_user_notification_dates CHECK (
        (read_at IS NULL OR read_at >= created_at) AND
        (expires_at IS NULL OR expires_at > created_at)
    )
);

CREATE TABLE notification_delivery_attempt (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_notification_id UUID NOT NULL REFERENCES user_notification(id) ON DELETE CASCADE,
    notification_destination_id UUID REFERENCES notification_destination(id) ON DELETE SET NULL,
    channel VARCHAR(20) NOT NULL,
    provider VARCHAR(80),
    provider_message_reference VARCHAR(255),
    status VARCHAR(20) NOT NULL,
    safe_error_code VARCHAR(100),
    attempted_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMPTZ,
    CONSTRAINT ck_notification_delivery_channel CHECK (channel IN ('IN_APP', 'EMAIL', 'PUSH')),
    CONSTRAINT ck_notification_delivery_status CHECK (status IN ('QUEUED', 'SENT', 'DELIVERED', 'FAILED', 'SKIPPED')),
    CONSTRAINT ck_notification_delivery_dates CHECK (completed_at IS NULL OR completed_at >= attempted_at)
);

CREATE TABLE dashboard_scope (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL UNIQUE REFERENCES app_user(id) ON DELETE CASCADE,
    display_currency CHAR(3) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT ck_dashboard_scope_currency CHECK (display_currency = UPPER(display_currency))
);

CREATE TABLE dashboard_scope_account (
    dashboard_scope_id UUID NOT NULL REFERENCES dashboard_scope(id) ON DELETE CASCADE,
    bank_account_id UUID NOT NULL REFERENCES bank_account(id) ON DELETE RESTRICT,
    PRIMARY KEY (dashboard_scope_id, bank_account_id)
);

CREATE TABLE dashboard_card_preference (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
    card_type VARCHAR(50) NOT NULL,
    visible BOOLEAN NOT NULL DEFAULT TRUE,
    position INTEGER NOT NULL,
    size VARCHAR(20) NOT NULL DEFAULT 'MEDIUM',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT uk_dashboard_card_type UNIQUE (user_id, card_type),
    CONSTRAINT uk_dashboard_card_position UNIQUE (user_id, position),
    CONSTRAINT ck_dashboard_card_position CHECK (position >= 0),
    CONSTRAINT ck_dashboard_card_size CHECK (size IN ('SMALL', 'MEDIUM', 'LARGE', 'FULL_WIDTH'))
);

CREATE INDEX idx_recommendation_user_status_priority
    ON personalized_recommendation(user_id, status, priority);
CREATE INDEX idx_recommendation_justification_recommendation
    ON recommendation_justification(recommendation_id);
CREATE INDEX idx_recommendation_interaction_date
    ON recommendation_interaction(recommendation_id, occurred_at DESC);
CREATE INDEX idx_financial_alert_user_status_severity
    ON financial_alert(user_id, status, severity);
CREATE INDEX idx_alert_occurrence_alert_date
    ON alert_occurrence(financial_alert_id, detected_at DESC);
CREATE INDEX idx_user_notification_inbox
    ON user_notification(user_id, read_at, created_at DESC);
CREATE INDEX idx_notification_delivery_notification_date
    ON notification_delivery_attempt(user_notification_id, attempted_at DESC);
CREATE INDEX idx_dashboard_scope_account_account
    ON dashboard_scope_account(bank_account_id);

-- No dashboard read-model table is persisted. The API composes the dashboard from source modules.
