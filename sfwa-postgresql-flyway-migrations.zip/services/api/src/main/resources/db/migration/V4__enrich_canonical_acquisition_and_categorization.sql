ALTER TABLE category
    ADD COLUMN user_id UUID REFERENCES app_user(id) ON DELETE CASCADE,
    ADD COLUMN parent_code VARCHAR(60) REFERENCES category(code) ON DELETE RESTRICT,
    ADD COLUMN label_key VARCHAR(100),
    ADD COLUMN color VARCHAR(20),
    ADD COLUMN icon VARCHAR(80),
    ADD COLUMN scope VARCHAR(20) NOT NULL DEFAULT 'SYSTEM',
    ADD CONSTRAINT ck_category_scope CHECK (
        (scope = 'SYSTEM' AND user_id IS NULL) OR
        (scope = 'USER' AND user_id IS NOT NULL)
    ),
    ADD CONSTRAINT ck_category_not_own_parent CHECK (parent_code IS NULL OR parent_code <> code);

UPDATE category SET label_key = 'category.' || LOWER(code) WHERE label_key IS NULL;
ALTER TABLE category ALTER COLUMN label_key SET NOT NULL;

CREATE UNIQUE INDEX uk_user_category_label
    ON category(user_id, LOWER(label_key))
    WHERE scope = 'USER';

CREATE TABLE bank_connection_authorization (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    connection_id UUID NOT NULL REFERENCES bank_connection(id) ON DELETE CASCADE,
    secret_reference VARCHAR(500) NOT NULL,
    granted_scopes TEXT NOT NULL,
    status VARCHAR(20) NOT NULL,
    authorized_at TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ,
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_bank_authorization_status CHECK (status IN ('ACTIVE', 'EXPIRED', 'REVOKED')),
    CONSTRAINT ck_bank_authorization_dates CHECK (
        (expires_at IS NULL OR expires_at > authorized_at) AND
        (revoked_at IS NULL OR revoked_at >= authorized_at)
    )
);

ALTER TABLE bank_account
    DROP CONSTRAINT bank_account_connection_id_fkey,
    ALTER COLUMN connection_id DROP NOT NULL,
    ADD COLUMN user_id UUID REFERENCES app_user(id) ON DELETE RESTRICT,
    ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    ADD COLUMN version INTEGER NOT NULL DEFAULT 0,
    ADD CONSTRAINT ck_bank_account_status CHECK (status IN ('ACTIVE', 'ARCHIVED', 'DISCONNECTED')),
    ADD CONSTRAINT ck_bank_account_currency CHECK (currency = UPPER(currency)),
    ADD CONSTRAINT ck_bank_account_origin CHECK (
        connection_id IS NOT NULL OR external_account_id LIKE 'manual:%'
    ),
    ADD CONSTRAINT fk_bank_account_connection
        FOREIGN KEY (connection_id) REFERENCES bank_connection(id) ON DELETE SET NULL;

UPDATE bank_account a
SET user_id = c.user_id
FROM bank_connection c
WHERE a.connection_id = c.id AND a.user_id IS NULL;

ALTER TABLE bank_account ALTER COLUMN user_id SET NOT NULL;

CREATE INDEX idx_bank_account_user_status ON bank_account(user_id, status);

CREATE TABLE balance_snapshot (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bank_account_id UUID NOT NULL REFERENCES bank_account(id) ON DELETE CASCADE,
    available_balance NUMERIC(19, 4),
    ledger_balance NUMERIC(19, 4),
    currency CHAR(3) NOT NULL,
    source VARCHAR(20) NOT NULL,
    observed_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_balance_snapshot UNIQUE (bank_account_id, observed_at, source),
    CONSTRAINT ck_balance_snapshot_source CHECK (source IN ('BANK_SYNC', 'FILE_IMPORT', 'MANUAL')),
    CONSTRAINT ck_balance_snapshot_currency CHECK (currency = UPPER(currency))
);

ALTER TABLE sync_job
    ADD COLUMN read_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN created_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN rejected_count INTEGER NOT NULL DEFAULT 0,
    ADD CONSTRAINT ck_sync_job_extended_counts
        CHECK (read_count >= 0 AND created_count >= 0 AND rejected_count >= 0);

ALTER TABLE import_job
    ADD COLUMN bank_account_id UUID REFERENCES bank_account(id) ON DELETE RESTRICT,
    ADD COLUMN detected_format VARCHAR(50),
    ADD COLUMN row_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN rejected_count INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN started_at TIMESTAMPTZ,
    ADD CONSTRAINT ck_import_job_extended_counts CHECK (row_count >= 0 AND rejected_count >= 0);

CREATE TABLE source_file (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    import_job_id UUID NOT NULL UNIQUE REFERENCES import_job(id) ON DELETE CASCADE,
    original_filename VARCHAR(255) NOT NULL,
    mime_type VARCHAR(160) NOT NULL,
    size_bytes BIGINT NOT NULL,
    sha256 CHAR(64) NOT NULL,
    storage_reference VARCHAR(500) NOT NULL,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_source_file_size CHECK (size_bytes > 0)
);

CREATE TABLE import_mapping (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    import_job_id UUID NOT NULL UNIQUE REFERENCES import_job(id) ON DELETE CASCADE,
    detection_method VARCHAR(30) NOT NULL,
    model_version VARCHAR(100),
    overall_confidence NUMERIC(5, 4),
    user_confirmed BOOLEAN NOT NULL DEFAULT FALSE,
    confirmed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_import_mapping_method CHECK (detection_method IN ('RULES', 'ML', 'LLM', 'USER')),
    CONSTRAINT ck_import_mapping_confidence CHECK (
        overall_confidence IS NULL OR overall_confidence BETWEEN 0 AND 1
    ),
    CONSTRAINT ck_import_mapping_confirmation CHECK (
        (user_confirmed = FALSE AND confirmed_at IS NULL) OR
        (user_confirmed = TRUE AND confirmed_at IS NOT NULL)
    )
);

CREATE TABLE column_mapping (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    import_mapping_id UUID NOT NULL REFERENCES import_mapping(id) ON DELETE CASCADE,
    source_column VARCHAR(255) NOT NULL,
    canonical_field VARCHAR(80) NOT NULL,
    detected_format VARCHAR(100),
    confidence NUMERIC(5, 4),
    confirmed BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT uk_column_mapping_source UNIQUE (import_mapping_id, source_column),
    CONSTRAINT ck_column_mapping_confidence CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1)
);

CREATE TABLE rejected_import_row (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    import_job_id UUID NOT NULL REFERENCES import_job(id) ON DELETE CASCADE,
    row_number INTEGER NOT NULL,
    error_code VARCHAR(100) NOT NULL,
    safe_error_message VARCHAR(500),
    masked_row_data JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_rejected_import_row UNIQUE (import_job_id, row_number),
    CONSTRAINT ck_rejected_import_row_number CHECK (row_number > 0)
);

ALTER TABLE transaction_record DROP CONSTRAINT ck_transaction_source;
ALTER TABLE transaction_record DROP CONSTRAINT ck_transaction_provenance;

ALTER TABLE transaction_record
    ALTER COLUMN source_type TYPE VARCHAR(20);

UPDATE transaction_record
SET source_type = CASE source_type
    WHEN 'BANK' THEN 'BANK_SYNC'
    WHEN 'FILE' THEN 'FILE_IMPORT'
    ELSE source_type
END;

ALTER TABLE transaction_record
    ADD COLUMN sync_job_id UUID REFERENCES sync_job(id) ON DELETE SET NULL,
    ADD COLUMN direction VARCHAR(10),
    ADD COLUMN original_description VARCHAR(1000),
    ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'POSTED',
    ADD COLUMN recurring BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN internal_transfer BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN version INTEGER NOT NULL DEFAULT 0;

UPDATE transaction_record
SET direction = CASE WHEN amount < 0 THEN 'DEBIT' ELSE 'CREDIT' END,
    amount = ABS(amount),
    original_description = description;

ALTER TABLE transaction_record
    ALTER COLUMN direction SET NOT NULL,
    ALTER COLUMN original_description SET NOT NULL,
    ADD CONSTRAINT ck_transaction_source CHECK (source_type IN ('BANK_SYNC', 'FILE_IMPORT', 'MANUAL')),
    ADD CONSTRAINT ck_transaction_direction CHECK (direction IN ('DEBIT', 'CREDIT')),
    ADD CONSTRAINT ck_transaction_positive_amount CHECK (amount > 0),
    ADD CONSTRAINT ck_transaction_currency CHECK (currency = UPPER(currency)),
    ADD CONSTRAINT ck_transaction_status CHECK (status IN ('PENDING', 'POSTED', 'CANCELLED')),
    ADD CONSTRAINT ck_transaction_provenance CHECK (
        (source_type = 'BANK_SYNC' AND bank_account_id IS NOT NULL AND import_job_id IS NULL) OR
        (source_type = 'FILE_IMPORT' AND import_job_id IS NOT NULL) OR
        (source_type = 'MANUAL' AND import_job_id IS NULL AND sync_job_id IS NULL)
    );

CREATE TABLE internal_transfer (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    outgoing_transaction_id UUID NOT NULL UNIQUE REFERENCES transaction_record(id) ON DELETE RESTRICT,
    incoming_transaction_id UUID NOT NULL UNIQUE REFERENCES transaction_record(id) ON DELETE RESTRICT,
    detection_method VARCHAR(30) NOT NULL,
    confidence NUMERIC(5, 4),
    confirmed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_internal_transfer_distinct CHECK (outgoing_transaction_id <> incoming_transaction_id),
    CONSTRAINT ck_internal_transfer_method CHECK (detection_method IN ('RULES', 'ML', 'USER')),
    CONSTRAINT ck_internal_transfer_confidence CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1)
);

CREATE TABLE category_prediction (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transaction_id UUID NOT NULL REFERENCES transaction_record(id) ON DELETE CASCADE,
    category_code VARCHAR(60) NOT NULL REFERENCES category(code) ON DELETE RESTRICT,
    method VARCHAR(30) NOT NULL,
    model_version VARCHAR(100),
    confidence NUMERIC(5, 4),
    explanation VARCHAR(1000),
    selected BOOLEAN NOT NULL DEFAULT FALSE,
    produced_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_category_prediction_method CHECK (method IN ('DEFAULT', 'RULES', 'ML', 'LLM', 'USER_HISTORY')),
    CONSTRAINT ck_category_prediction_confidence CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1)
);

ALTER TABLE category_feedback
    ADD COLUMN correction_source VARCHAR(30) NOT NULL DEFAULT 'USER',
    ADD CONSTRAINT ck_category_feedback_source CHECK (correction_source IN ('USER', 'BULK_USER_ACTION', 'ADMIN_MIGRATION'));

CREATE UNIQUE INDEX uk_selected_category_prediction
    ON category_prediction(transaction_id)
    WHERE selected = TRUE;

CREATE INDEX idx_balance_snapshot_account_date ON balance_snapshot(bank_account_id, observed_at DESC);
CREATE INDEX idx_sync_job_connection_date ON sync_job(connection_id, created_at DESC);
CREATE INDEX idx_import_job_user_date ON import_job(user_id, created_at DESC);
CREATE INDEX idx_transaction_account_date ON transaction_record(bank_account_id, booking_date DESC);
CREATE INDEX idx_transaction_category_date ON transaction_record(category_code, booking_date DESC);
CREATE INDEX idx_category_prediction_transaction_date ON category_prediction(transaction_id, produced_at DESC);
