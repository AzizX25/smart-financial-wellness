# PostgreSQL and Flyway schema

This directory documents the executable PostgreSQL schema in
`services/api/src/main/resources/db/migration`.

The SQL uses English technical names to stay consistent with the Spring Boot
codebase. They map directly to the French domain model used in the design
documentation.

## Migration order

| Migration | Main responsibility |
| --- | --- |
| `V1__create_core_schema.sql` | Initial users, bank acquisition, canonical transactions and categories |
| `V2__seed_category_taxonomy.sql` | Stable system category codes |
| `V3__add_user_preferences_security_and_consent.sql` | Profile, preferences, sessions, MFA, legal documents and consent history |
| `V4__enrich_canonical_acquisition_and_categorization.sql` | Manual accounts, balance history, import mapping, transaction provenance and category predictions |
| `V5__add_salary_planning_and_goals.sql` | Monthly salary planning, budgets, goals, contributions and saved goal simulations |
| `V6__add_forecasts_and_wellness_evaluations.sql` | Multi-account forecasts and explainable, versioned wellness evaluations |
| `V7__add_recommendations_alerts_notifications_and_dashboard.sql` | Active recommendations, alert lifecycle, notifications and dashboard preferences |
| `V8__add_audit_and_personal_data_lifecycle.sql` | Append-only audit data, data-subject requests, exports and retention policies |
| `V9__add_cross_aggregate_invariants_and_update_triggers.sql` | Ownership, currency, immutability, allocation and publication invariants |

Spring Boot discovers these migrations automatically through the configured
`classpath:db/migration` Flyway location.

## Domain mapping

| French design term | PostgreSQL table or value |
| --- | --- |
| `Utilisateur` | `app_user` |
| `CompteFinancier` | `bank_account` (bank-connected or manual) |
| `TransactionFinanciere` | `transaction_record` |
| `PlanMensuel` | `monthly_plan` |
| `AllocationObjectif` | `goal_allocation` |
| `ContributionObjectif` | `goal_contribution` |
| `ScenarioObjectif` | `goal_scenario` |
| `ExecutionPrevision` | `forecast_run` |
| `EvaluationBienEtre` | `wellness_evaluation` |
| `RecommandationPersonnalisee` | `personalized_recommendation` |
| `AlerteFinanciere` | `financial_alert` |
| `NotificationUtilisateur` | `user_notification` |
| `PorteeTableauDeBord` | `dashboard_scope` |

## Intentional non-tables

The following concepts are calculated or transient and therefore have no
table:

- dashboard view and dashboard cards;
- forecast simulation scenarios;
- current goal progress;
- current wellness score;
- saving capacity outside its owning monthly plan.

Saved goal scenarios are persistent because users can name, revisit and compare
them. Forecast simulations remain temporary request/response data and must not
modify transactions, plans or stored forecasts.

## Important compatibility changes in V4

`V4` evolves the initial canonical transaction representation:

- `source_type = BANK` becomes `BANK_SYNC`;
- `source_type = FILE` becomes `FILE_IMPORT`;
- `MANUAL` becomes available;
- `amount` becomes strictly positive;
- `direction` explicitly carries `DEBIT` or `CREDIT`;
- the original description is preserved separately;
- synchronization provenance, recurrence, posting state and internal-transfer
  state are added.

On an existing environment, run this migration against a staging copy first.
Existing zero-value transactions violate the new positive-amount invariant and
must be reviewed as data-quality errors before migration.

## Database-enforced invariants

The database rejects, among other cases:

- a connected account assigned to a different user than its connection;
- transactions, imports, forecasts or dashboard scopes crossing user
  boundaries;
- user-defined categories applied to another user's data;
- a plan and goal with different users or currencies;
- confirmed goal allocations above the calculated saving capacity;
- an evaluation published without dimensions, indicators or weights summing to
  one;
- edits to a produced evaluation, except its transition to `OBSOLETE`;
- activation of a recommendation without a factual justification;
- an internal transfer that is not a same-user, same-currency debit/credit pair;
- notifications, alerts or recommendations linked across users.

The backend must still enforce authorization on every query, require explicit
confirmation before applying a proposed action, minimize data sent to external
AI services and orchestrate account deletion according to the retention policy.

## Operational notes

- Migrations are forward-only and should not be edited after deployment.
- Test the full sequence on a clean PostgreSQL database in CI.
- Test upgrades from the latest production backup before every release.
- Keep Hibernate in `ddl-auto: validate`; Flyway remains the schema owner.
- Do not enable generic cascade deletion from `app_user` as a substitute for the
  dedicated personal-data deletion workflow.
