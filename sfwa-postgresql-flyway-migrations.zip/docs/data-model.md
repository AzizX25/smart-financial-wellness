# Data model baseline

## SFWA database

```mermaid
erDiagram
    APP_USER ||--o{ REFRESH_TOKEN : owns
    APP_USER ||--o{ BANK_CONNECTION : authorizes
    APP_USER ||--o{ IMPORT_JOB : uploads
    APP_USER ||--o{ FINANCIAL_GOAL : defines
    APP_USER ||--o{ SCORE_SNAPSHOT : receives
    BANK_CONNECTION ||--o{ BANK_ACCOUNT : exposes
    BANK_CONNECTION ||--o{ SYNC_JOB : executes
    BANK_ACCOUNT ||--o{ TRANSACTION_RECORD : contains
    IMPORT_JOB ||--o{ TRANSACTION_RECORD : produces
    CATEGORY ||--o{ TRANSACTION_RECORD : classifies
    TRANSACTION_RECORD ||--o{ CATEGORY_FEEDBACK : receives
    FINANCIAL_GOAL ||--o{ GOAL_ALLOCATION : receives

    APP_USER {
        uuid id PK
        string email UK
        string password_hash
        string preferred_currency
        string locale
        instant created_at
    }
    BANK_CONNECTION {
        uuid id PK
        uuid user_id FK
        string provider
        string status
        text encrypted_access_token
        text encrypted_refresh_token
        instant consent_expires_at
        instant last_synced_at
    }
    BANK_ACCOUNT {
        uuid id PK
        uuid connection_id FK
        string external_account_id
        string masked_identifier
        string account_type
        string currency
        decimal current_balance
    }
    TRANSACTION_RECORD {
        uuid id PK
        uuid user_id FK
        uuid bank_account_id FK
        uuid import_job_id FK
        string source_type
        string external_transaction_id
        string fingerprint
        date booking_date
        decimal amount
        string direction
        string currency
        string description
        string merchant_normalized
        string category_code FK
        decimal category_confidence
        string model_version
    }
    CATEGORY {
        string code PK
        string taxonomy_version
        string direction
    }
    IMPORT_JOB {
        uuid id PK
        uuid user_id FK
        string status
        string original_filename
        json proposed_mapping
        json confirmed_mapping
        instant created_at
    }
    SYNC_JOB {
        uuid id PK
        uuid connection_id FK
        string status
        instant started_at
        instant completed_at
        int imported_count
        int duplicate_count
    }
    FINANCIAL_GOAL {
        uuid id PK
        uuid user_id FK
        string name
        decimal target_amount
        decimal current_amount
        date target_date
        string status
    }
```

### Canonical transaction invariants

- `amount` is strictly positive and `direction` is `CREDIT` or `DEBIT`.
- `currency` is an ISO 4217 uppercase code.
- `source_type` is `BANK_SYNC`, `FILE_IMPORT` or `MANUAL`.
- A bank transaction is unique by `(bank_account_id, external_transaction_id)` when an external ID exists.
- `fingerprint` provides idempotency when a source has no stable transaction ID.
- Raw source data is not used directly by analytics; normalization happens before persistence.
- User corrections do not erase the original prediction metadata.
- Internal transfers remain visible on their accounts but are excluded from consolidated income and expense totals.
- Salary planning and goals remain separate aggregates linked by `goal_allocation`.
- Goal simulations are saved; forecast simulations are intentionally transient.
- Produced wellness evaluations are immutable and keep their method version, dimensions and indicators.

## Simulated bank database

```mermaid
erDiagram
    BANK_CUSTOMER ||--o{ BANK_ACCOUNT : owns
    BANK_ACCOUNT ||--o{ BANK_TRANSACTION : contains
    BANK_CUSTOMER ||--o{ CONSENT : grants
    OAUTH_CLIENT ||--o{ CONSENT : receives
    CONSENT ||--o{ AUTHORIZATION_CODE : creates
    CONSENT ||--o{ ACCESS_TOKEN : authorizes

    BANK_CUSTOMER {
        uuid id PK
        string username UK
        string password_hash
        string display_name
        string status
    }
    OAUTH_CLIENT {
        string client_id PK
        string client_secret_hash
        string redirect_uri
        string status
    }
    CONSENT {
        uuid id PK
        uuid customer_id FK
        string client_id FK
        string scopes
        string status
        instant expires_at
    }
    ACCESS_TOKEN {
        uuid id PK
        uuid consent_id FK
        string token_hash UK
        string refresh_token_hash UK
        instant expires_at
        instant revoked_at
    }
    BANK_ACCOUNT {
        uuid id PK
        uuid customer_id FK
        string account_number_masked
        string account_type
        string currency
        decimal current_balance
        string status
    }
    BANK_TRANSACTION {
        uuid id PK
        uuid account_id FK
        date booking_date
        decimal amount
        string currency
        string description
        string merchant
    }
```

The simulated bank contains fictitious data only. It must never reuse real credentials or imported financial data.
